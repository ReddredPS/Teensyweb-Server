#
# file::    wiki_config.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

ActiveRecord::Base.colorize_logging = false

require 'bluecloth'
require 'syntax/convertors/html'

TWCONFIG = YAML::load_file("#{RAILS_ROOT}/config/wiki_config.yml")

ActionMailer::Base.delivery_method = :smtp
ActionMailer::Base.server_settings = {
  :address  => TWCONFIG['mail_server'],
  :domain => TWCONFIG['mail_domain'],
  :port   => 25, # replace with your SMTP server's port
  :password       => nil, # set if your SMTP server requires authentication
  :authentication => nil  # set to true if your SMTP server requires authentication
}

WIKI_LINK_PATTERN = /([A-Z]+[a-z]+[A-Z][A-Za-z_0-9]*)(?:"")?/
ANCHOR_LINK_PATTERN = /([A-Z]+[a-z]+[A-Z][A-Za-z_0-9]*)#(\w+)(?:"")?/
FREE_LINK_PATTERN = /([-,.()' _0-9A-Za-z]+)(?:"")?/
URL_PATTERN = /((?:(?:http|https|ftp|afs|news|nntp|mid|cid|mailto|wais|prospero|telnet|gopher|file):[^\]\s"<>\xb3]+)(?:"")?)/
ISBN_PATTERN = /ISBN:?([0-9\- xX]{10,})/
IMAGE_URL_PATTERN = /^(http:|https:|ftp:|file:).+\.(gif|jpg|png|bmp|jpeg)$/

RUBY_CODE_PATTERN = /\[ruby\](.*?)\[\/ruby\]/im
GRAPH_CODE_PATTERN = /\[graph (\w+?)\](.*?)\[\/graph\]/im


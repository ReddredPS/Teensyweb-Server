#
# file::    user.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#
#
# This code originally written by Tobias Luetke and part of
# login_generator (1.1.0) and found in user.rb.
#


# this model expects a certain database layout and its based on the name/login pattern.
class User < ActiveRecord::Base

  # Authenticate a user.
  #
  # Example:
  #   @user = User.authenticate('bob', 'bobpass')
  #
  def self.authenticate(login, password)
    return nil if login.size < 3
    find_first(["login = ? AND password = ?", login, password.crypt(login)])
  end

protected

  before_create :crypt_password
  # Before saving the record to database we will crypt the password
  # using SHA1.
  # We never store the actual password in the DB.
  def crypt_password
    write_attribute "password", password.crypt(login)
  end

  before_update :crypt_unless_empty
  # If the record is updated we will check if the password is empty.
  # If its empty we assume that the user didn't want to change his
  # password and just reset it to the old value.
  def crypt_unless_empty
    if password.empty?
      self.password = self.class.find(self.id).password
    else
      write_attribute "password", password.crypt(login)
    end
  end

  validates_uniqueness_of :login, :on => :create
  validates_length_of :login, :within => 3..40
  validates_length_of :password, :within => 5..40
  validates_presence_of :login, :email, :password
end

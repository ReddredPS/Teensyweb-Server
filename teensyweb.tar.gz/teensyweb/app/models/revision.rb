#
# file::    revision.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

class Revision < ActiveRecord::Base
  belongs_to :page
  belongs_to :user

end

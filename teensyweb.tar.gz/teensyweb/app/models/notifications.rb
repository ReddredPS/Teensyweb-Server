#
# file::    notifications.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

class Notifications < ActionMailer::Base

  def signup(user, password)
    @subject    = "[#{TWCONFIG['site_name']}] Your account information"
    @recipients = "#{user.login} <#{user.email}>"
    @from       = TWCONFIG['mail_from']
    @sent_on    = Time.now
    @headers    = {}
    # Email body substitutions
    @body["login"] = user.login
    @body['pass'] = password

  end

  def forgot_password(user, password)
    @subject    = "[#{TWCONFIG['site_name']}] Your account information"
    @recipients = "#{user.login} <#{user.email}>"
    @from       = TWCONFIG['mail_from']
    @sent_on    = Time.now
    @headers    = {}
    # Email body substitutions
    @body["login"] = user.login
    @body['pass'] = password
  end
end

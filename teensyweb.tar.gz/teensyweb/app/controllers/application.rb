#
# file::    application.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#
#
# This code originally written by Tobias Luetke and part of
# login_generator (1.1.0) and found in login_system.rb.
#


# Filters added to this controller will be run for all controllers in the application.
# Likewise, all the methods added will be available for all controllers.
class ApplicationController < ActionController::Base
  model :user

  helper_method :user?
  helper_method :admin?
  helper_method :owner?
  helper_method :msie?

  def msie?
    puts request
    if request.env['HTTP_USER_AGENT'] =~ /IE/
      true
    else
      false
    end
  end

  def user?
    !session['user'].nil?
  end

  def owner?(uid)
    !session['user'].nil? && session['user']['id'] == uid
  end

  def admin?
    user? && session['user'].admin == 1
  end

  # admin_required filter. add
  #
  #   before_filter :admin_required
  #
  # if the controller should be under any rights management.
  # for finer access control you can overwrite
  #
  #   def authorize?(user)
  #
  def admin_required
    return true if admin?

    # store current location so that we can
    # come back after the user logged in
    store_location

    # call overwriteable reaction to unauthorized access
    flash['notice']  = "Admin priviledges required"
    redirect_back_or_default :controller=>"wiki"
    return false
  end

  # login_required filter. add
  #
  #   before_filter :login_required
  #
  # if the controller should be under any rights management.
  # for finer access control you can overwrite
  #
  #   def authorize?(user)
  #
  def login_required
    return true if user?

    # store current location so that we can
    # come back after the user logged in
    store_location

    # call overwriteable reaction to unauthorized access
    redirect_to :controller=>"account", :action =>"login"
    return false
  end

  # store current uri in  the session.
  # we can return to this location by calling return_location
  def store_location
    session['return_to'] = request.request_uri
  end

  # move to the last store_location call or to the passed default one
  def redirect_back_or_default(default)
    if session['return_to'].nil?
      redirect_to default
    else
      redirect_to_url session['return_to']
      session['return_to'] = nil
    end
  end

end


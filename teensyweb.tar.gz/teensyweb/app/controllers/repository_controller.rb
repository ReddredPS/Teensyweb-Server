#
# file::    repository_controller.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

class RepositoryController < ApplicationController

  layout  'layout'

  def index
   @fpath = params['path'].join('/')
   @files = []
   tmp = `svn ls #{TWCONFIG['repository']}/#{@fpath}`
   @files = tmp.split
   @back = @fpath.gsub(/\/\w+$|^\w+$/, "")
   @title = "Browse repository"
  end

  def show
   @fname = params['path'].pop
   @fpath = params['path'].join('/')
   @back = @fpath
   @file = `svn cat #{TWCONFIG['repository']}/#{@fpath}/#{@fname}`
   @title = "Browse repository"
  end

  def changelog
   @changelog = ""
   @changelog = `svn log --limit 10 #{TWCONFIG['repository']}`
   @title = "Changelog"
  end

end

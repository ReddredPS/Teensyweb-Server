#
# file::    wiki_controller.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

class WikiController < ApplicationController
  model   :page, :revision, :user
  before_filter :login_required, :only => [:edit]
  before_filter :admin_required, :only => [:rename, :lock]
  layout  'layout'
  helper_method :page_name
  helper_method :rev_name

  def page_name
    if params['id'].nil?
      return TWCONFIG['home_page'] || "HomePage"
    end
    URI.unescape(params['id']) =~ WIKI_LINK_PATTERN
    if $1.nil?
      flash['notice']  = "Invalid page name"
      TWCONFIG['home_page'] || "HomePage"
    else
      $1
    end
  end

  def rev_name
    params['rev']
  end

  def index
    redirect_to(:action => "show", :id => page_name)
  end

  def show
    @page = Page.find_by_name(page_name)
    redirect_to(:action => "edit", :id => page_name) && return if !@page
    if rev_name
      @revision = Revision.find(rev_name, :conditions => [ "page_id == ?", @page.id])
    else
      @revision = @page.revision
    end
  end

  def raw
    @page = Page.find_by_name(page_name)
    redirect_to(:action => "edit", :id => page_name) && return if !@page
    if rev_name
      @revision = Revision.find(rev_name, :conditions => [ "page_id == ?", @page.id])
    else
      @revision = @page.revision
    end
  end

  def edit
    @page = Page.find_by_name(page_name) || Page.new('name' => page_name, 'revision_id' => 0)
    if !admin? && @page.page_locked == 1
      flash['notice']  = 'Page locked'
      redirect_to(:action => "show", :id => page_name) && return
    end
    if rev_name
      @revision = Revision.find(rev_name, :conditions => [ "page_id == ?", @page.id])
    else
      @revision = @page.revision || Revision.new('data' => 'Describe page here')
    end
    if request.post?
      case params['commit']
      when 'Save'
        @page.save
        begin
          host = Socket.gethostbyname(request.remote_ip)[0]
        rescue
          host = request.remote_ip
        end
        @revision = Revision.new('data' => params['content'], 'user_id' => session['user']['id'],
          'page_id' => @page.id, 'ip' => request.remote_ip, 'host' => host,
                                 'comment' => params['comment']
                                 )
        @revision.save
        @page.revision_id = @revision.id
        @page.save
        flash['notice']  = "Page saved"
        redirect_to(:action => "show", :id => page_name)
      when 'Preview'
        @revision = Revision.new('data' => params['content'], 'comment' => params['comment'])
        @preview = true
        flash['notice']  = "Preview"
      when 'Cancel'
        flash['notice']  = "Edit cancelled"
        redirect_to(:action => "show", :id => page_name)
      end
    end
  end

  def recent
    # seven days
    @pages = Page.find(:all, :conditions => [ "updated_at > ?", Time.now - 60*60*24*7]).sort {|a,b| b.updated_at <=> a.updated_at}
    @title = "Pages changed in last 7 days"
  end

  def rss
    # seven days
    @pages = Page.find(:all, :conditions => [ "updated_at > ?", Time.now - 60*60*24*7]).sort {|a,b| b.updated_at <=> a.updated_at}
    @title = "Pages changed in last 7 days"
    render_without_layout
  end

  def all
    @pages = Page.find(:all).sort {|a,b| a.name <=> b.name}
    @title = "All pages"
  end

  def search
    @query = params['query']
    @results = []
    return if @query == ''
    revs = Revision.find_by_sql "select * from revisions r, pages p where p.revision_id == r.id"
    revs.each do |r|
      @results << r if r.name =~ /#{@query}/i || r.data =~ /#{@query}/i
    end
    @title = "Wiki pages found for query \"#{@query}\""
  end

  def backrefs
    @results = []
    revs = Revision.find_by_sql "select * from revisions r, pages p where p.revision_id == r.id"
    revs.each do |r|
      @results << r if r.data =~ /#{page_name}/
    end
    @title = "Back references for: #{page_name}"
  end

  def revisions
    @page = Page.find_by_name(page_name)
    @revisions = Revision.find(:all, :conditions => [ "page_id == ?", @page.id])
    @title = "Revision list"
  end

  def lock
    return if !admin?
    @page = Page.find_by_name(page_name)
    return if !@page
    @page.page_locked = @page.page_locked == 0 ? 1 : 0 # toggle
    @page.save
    redirect_to(:action => "show", :id => page_name)
  end

  def rename
    redirect_to(:action => "show", :id => page_name)
  end

end

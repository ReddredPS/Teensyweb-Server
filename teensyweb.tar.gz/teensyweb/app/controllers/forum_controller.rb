#
# file::    forum_controller.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

class ForumController < ApplicationController
  before_filter :admin_required, :only => [:edit, :new, :delete, :postdelete, :topicdelete]
  before_filter :login_required, :only => [:postedit, :postnew, :postreply]

  layout  'layout'

  def index
    redirect_to :action => 'list'
  end

  def list
    @forums = Forum.find_all(nil)
    @title = "Forum list"
  end

  def new
    @title = "Create a new forum"
    if request.post?
      @forum = Forum.new('name' => params['name'], 'description' => params['description'])
      @forum.save
      redirect_to :action => 'list'
    end
  end

  def edit
    @title = "Edit forum"
    @forum = Forum.find(params['id'])
    if request.post?
      @forum.name = params['name']
      @forum.description = params['description']
      @forum.save
      redirect_to :action => 'list'
    end
  end

  def delete
    @forum = Forum.find(params['id'])
    @forum.topics.each {|t|
      t.posts.each {|p| p.destroy }
      t.destroy
    }
    @forum.destroy
    redirect_to :action => 'list'
  end

  def search
    @query = params['query']
    @results = []
    return if @query == ''
    posts = Post.find_all(nil)
    posts.each do |p|
      @results << p if p.data =~ /#{@query}/i
    end
    @title = "Posts found for query \"#{@query}\""
  end

  def topiclist
    @forum = Forum.find(params['id'])
    @topics = @forum.topics.sort {|i,j| j.updated_at <=> i.updated_at }
    @title = "Topics: #{@forum.name}"
  end

  def topicdelete
    @topic = Topic.find(params['id'])
    @forum = @topic.forum
    @posts = @topic.posts
    @posts.each {|p| p.destroy }
    @topic.destroy
    redirect_to(:action => "topiclist", :id => @forum.id)
  end

  def postlist
    @topic = Topic.find(params['id'])
    @forum = @topic.forum
    @posts = @topic.posts
    @title = "Subject: #{@topic.subject}"
  end

  def postrecent
    # two days
    @posts = Post.find(:all, :conditions => [ "updated_at > ?", Time.now - 60*60*24*2]).sort {|a,b| b.updated_at <=> a.updated_at}
    @title = "Recently posted in the last 2 days"
  end

  def rss
    # three days
    @posts = Post.find(:all, :conditions => [ "updated_at > ?", Time.now - 60*60*24*2]).sort {|a,b| b.updated_at <=> a.updated_at}
    @title = "Recently posted in the last 2 days"
    render_without_layout
  end

  def postdelete
    @post = Post.find(params['id'])
    @topic = @post.topic
    @forum = @topic.forum
    @post.destroy
    redirect_to(:action => "postlist", :id => @topic.id)
  end

  def postshow
    @post = Post.find(params['id'])
    @topic = @post.topic
    @forum = @topic.forum
    @title = "Subject: #{@topic.subject}"
  end

  def postnew
    @forum = Forum.find(params['id'])
    @topic = Topic.new
    @post = Post.new
    @title = "New post"
    if request.post?
      case params['commit']
      when 'Save'
        begin
          host = Socket.gethostbyname(request.remote_ip)[0]
        rescue
          host = request.remote_ip
        end
        @topic.subject = params['subject']
        @topic.forum_id = @forum.id
        @topic.save
        @post.data = params['content']
        @post.user_id = session['user']['id']
        @post.topic_id = @topic.id
        @post.ip = request.remote_ip
        @post.host = host
        @post.save
        flash['notice']  = "Post saved"
        redirect_to(:action => "topiclist", :id => @forum.id)
      when 'Preview'
        @topic.subject = params['subject']
        @post.data = params['content']
        @preview = true
        flash['notice']  = "Preview"
      when 'Cancel'
        flash['notice']  = "Post cancelled"
        redirect_to(:action => "topiclist", :id => @forum.id)
      end
    end
  end

  def postreply
    @replyto = Post.find(params['id'])
    @topic = @replyto.topic
    @forum = @topic.forum
    @post = Post.new
    @title = "Reply to: #{@topic.subject}"
    if request.post?
      case params['commit']
      when 'Save'
        begin
          host = Socket.gethostbyname(request.remote_ip)[0]
        rescue
          host = request.remote_ip
        end
        @post.data = params['content']
        @post.user_id = session['user']['id']
        @post.topic_id = @topic.id
        @post.ip = request.remote_ip
        @post.host = host
        @post.save
        flash['notice']  = "Post saved"
        redirect_to(:action => "postlist", :id => @topic.id)
      when 'Preview'
        @post.data = params['content']
        @preview = true
        flash['notice']  = "Preview"
      when 'Cancel'
        flash['notice']  = "Post cancelled"
        redirect_to(:action => "postlist", :id => @topic.id)
      end
    end
  end

  def postedit
    @post = Post.find(params['id'])
    @topic = @post.topic
    @forum = @topic.forum
    @title = "Edit post: #{@topic.subject}"
    if !owner?(@post.user_id)
      flash['notice']  = "Cannot edit"
      redirect_to(:action => "postlist", :id => @topic.id)
    end
    if request.post?
      case params['commit']
      when 'Save'
        begin
          host = Socket.gethostbyname(request.remote_ip)[0]
        rescue
          host = request.remote_ip
        end
        @post.data = params['content']
        @post.ip = request.remote_ip
        @post.host = host
        @post.save
        flash['notice']  = "Post saved"
        redirect_to(:action => "postlist", :id => @topic.id)
      when 'Preview'
        @post.data = params['content']
        @preview = true
        flash['notice']  = "Preview"
      when 'Cancel'
        flash['notice']  = "Post cancelled"
        redirect_to(:action => "postlist", :id => @topic.id)
      end
    end
  end

end

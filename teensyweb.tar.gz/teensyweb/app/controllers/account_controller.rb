#
# file::    account_controller.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

class AccountController < ApplicationController
  before_filter :admin_required, :only => [:delete]
  before_filter :login_required, :only => [:edit, :list, :index]

  layout  'layout'

  def random_password
    ("a".."z").to_a.sort_by { rand }[0..5].to_s
  end

  def index
    redirect_to :action => 'list'
  end

  def login
    @title = "Please login"
    if request.post?
      case params['commit']
      when 'Login'
        params['password'] = params['password'].strip
        if session['user'] = User.authenticate(params['login'], params['password'])
          flash['notice']  = "Login successful"
          redirect_back_or_default :controller => "wiki"
        else
          flash.now['notice']  = "Login unsuccessful"
          @login = params['login']
        end
      when 'Forgot Password'
        @user = User.find_by_login(params['login'])
        if !@user
          flash['notice']  = 'No user by that name'
        end
        pw = random_password
        @user.password = pw
        @user.save
        if @user.errors.empty?
          flash['notice']  = "Sent password"
          Notifications.deliver_forgot_password(@user, pw) if TWCONFIG['mail_on']
          session['user'] = nil
          redirect_back_or_default :controller => "wiki"
        else
          flash['notice'] = @user.errors.full_messages.join("<br />")
        end
      end
    end
  end

  def signup
    @title = "Signup for account"
    if request.post?
      pw = random_password
      @user = User.new('login' => params['login'],
                       'email' => params['email'],
                       'password' => pw,
                       'admin' => (User.count == 0 ? 1 : 0)
                       )
      @user.save
      if @user.errors.empty?
        flash['notice']  = "Signup successful"
        Notifications.deliver_signup(@user, pw) if TWCONFIG['mail_on']
        redirect_back_or_default :controller => "wiki"
      else
        flash['notice'] = @user.errors.full_messages.join("<br />")
      end
    end
  end

  def logout
    if !user?
      flash['notice']  = "You aren't logged in"
    else
      session['user'] = nil
      flash['notice']  = "Logged out"
    end
    redirect_back_or_default :controller => "wiki"
  end

  def welcome
  end

  def list
    @title = "User listing"
    @users = User.find_all
  end

  def edit
    if request.get?
      if admin? || session['user'].login == params['id']
        @user = User.find_by_login(params['id'])
        if !@user.errors.empty?
          flash['notice'] = @user.errors.full_messages.join("<br />")
          redirect_back_or_default :controller => "wiki"
        end
        @title = "User preferences for #{@user.login}"
      else
        flash['notice']  = "Can't do user preferences"
        redirect_back_or_default :controller => "wiki"
      end
    else
      @user = User.find_by_login(params['id'])
      @title = "User preferences for #{@user.login}"
      case params['commit']
      when 'Update'
        @user.email = params['email']
        @user.admin = (params['admin'] && params['admin'] == '1') ? 1 : 0
        @user.password = ''
        @user.save_with_validation(false)
        if @user.errors.empty?
          flash['notice']  = "Preferences saved"
          redirect_back_or_default :controller => "wiki"
        else
          flash['notice'] = @user.errors.full_messages.join("<br />")
        end
      when 'Change Password'
        params['password'] = params['password'].strip
        params['password_confirmation'] = params['password_confirmation'].strip
        if params['password'] != params['password_confirmation']
          flash['notice']  = "Password and confirmation don't match"
        else
          @user.password = params['password']
          @user.save
          if @user.errors.empty?
            flash['notice']  = "Password changed"
            session['user'] = nil
            redirect_back_or_default :controller => "wiki"
          else
            flash['notice'] = @user.errors.full_messages.join("<br />")
          end
        end
      end
    end
  end

  def delete
    if params['id']
      @user = User.find_by_login(params['id'])
      @user.destroy
      if !@user.errors.empty?
        flash['notice'] = @user.errors.full_messages.join("<br />")
      end
    end
    redirect_to :action => 'list'
  end

end


#
# file::    wiki_helper.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

module WikiHelper

  def wikify(str)
    tags = %w(a map pre)
    stags = %w(img)

    s = str

    # Embed ruby
    if s =~ RUBY_CODE_PATTERN
      convertor = Syntax::Convertors::HTML.for_syntax "ruby"
      s.gsub!(RUBY_CODE_PATTERN) {|m|
        convertor.convert($1,true)
      }
    end

    # Embed graph
    if s =~ GRAPH_CODE_PATTERN
      File.open("public/graphs/#{$1}.dot","wb") {|f|
        f.write $2
      }
      `dot -Tcmap -opublic\\graphs\\#{$1}.map -Tpng -opublic\\graphs\\#{$1}.png public\\graphs\\#{$1}.dot`
      s.gsub!(GRAPH_CODE_PATTERN) {|m|
         "<img src=\"/graphs/#{$1}.png\" usemap=\"#{$1}\" /><map id=\"#{$1}\" name=\"#{$1}\">#{`cat public\\graphs\\#{$1}.map`}</map>"
      }
    end

    # markdown
    s = BlueCloth.new(s).to_html

    # save text surrounded by tags
    savepre = {}
    saveidx = 0
    tags.each do |tg|
      s.gsub!(/<#{tg}.*?\/#{tg}>/mi) {
        saveidx += 1
        savepre[saveidx] = $&
        "ZZZ#{saveidx}ZZZ"
      }
    end
    stags.each do |tg|
      s.gsub!(/<#{tg}.*?>/mi) {
        saveidx += 1
        savepre[saveidx] = $&
        "ZZZ#{saveidx}ZZZ"
      }
    end

    # Wiki words
    s.gsub!(WIKI_LINK_PATTERN) {|m|
      Page.find_by_name($1) ?
      "<a href='/wiki/show/#{$1}'>#{$1}</a>" :
      "#{$1}<a href='/wiki/edit/#{$1}'>?</a>"
    }

    # restore text from tags
    s.gsub!(/ZZZ(\d+?)ZZZ/mi) {
      savepre[$1.to_i]
    }

    s
  end

end

#
# file::    repository_helper.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

module RepositoryHelper

  def format_text(str, t=nil)
    s = str

    if t
      # Embed ruby
      convertor = Syntax::Convertors::HTML.for_syntax "ruby"
      s = convertor.convert(s,true)
    end

    s.gsub!(/\n/, "<br />")

    s

  end
end

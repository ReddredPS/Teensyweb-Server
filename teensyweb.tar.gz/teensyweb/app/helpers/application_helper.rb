#
# file::    application_helper.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

# Methods added to this helper will be available to all templates in the application.
module ApplicationHelper

  def browser_title
    "#{TWCONFIG['site_name']} : #{controller.controller_name.capitalize}"
  end

  def page_title
    if controller.controller_name == 'wiki'
      @title || link_to(page_name ,{:action => 'backrefs', :id => page_name})
    else
      @title || controller.action_name.capitalize
    end
  end

  def wiki_words(str)
    str.scan(WIKI_LINK_PATTERN).join(",")
  end

  def ftime(t)
    t.strftime("%m/%d/%Y %I:%M%p")
  end
end

#
# file::    002_add_forum.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

class AddForum < ActiveRecord::Migration
  def self.up
    create_table "forums", :force => true do |t|
      t.column "created_at", :datetime, :null => false
      t.column "updated_at", :datetime, :null => false
      t.column "name", :text, :null => false
      t.column "description", :text, :null => false
    end

    create_table "topics", :force => true do |t|
      t.column "created_at", :datetime, :null => false
      t.column "updated_at", :datetime, :null => false
      t.column "subject", :text, :null => false
      t.column "forum_id", :integer, :null => false
    end

    add_index "topics", ["forum_id"], :name => "topics_forum_id_index"

    create_table "posts", :force => true do |t|
      t.column "created_at", :datetime, :null => false
      t.column "updated_at", :datetime, :null => false
      t.column "topic_id", :integer, :null => false
      t.column "user_id", :integer, :null => false
      t.column "data", :text, :null => false
      t.column "host", :text, :null => false
      t.column "ip", :text, :null => false
    end

    add_index "posts", ["topic_id"], :name => "posts_topic_id_index"
    add_index "posts", ["user_id"], :name => "posts_user_id_index"
  end

  def self.down
  end
end

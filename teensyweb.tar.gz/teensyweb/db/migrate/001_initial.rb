#
# file::    001_initial.rb
# author::  Jon A. Lambert
# version:: 0.1.0
# date::    1/6/2006
#
# This source code copyright (C) 2006 by Jon A. Lambert
# All rights reserved.
#
# Released under the terms of the TeensyWeb Public License
# See LICENSE file for additional information.
#

class Initial < ActiveRecord::Migration
  def self.up

    create_table "pages", :force => true do |t|
      t.column "created_at", :datetime, :null => false
      t.column "updated_at", :datetime, :null => false
      t.column "name", :text, :null => false
      t.column "revision_id", :integer, :null => false
      t.column "page_locked", :integer, :default => 0, :null => false
    end

    add_index "pages", ["name"], :name => "pages_name_index", :unique => true

    create_table "revisions", :force => true do |t|
      t.column "created_at", :datetime, :null => false
      t.column "updated_at", :datetime, :null => false
      t.column "page_id", :integer, :null => false
      t.column "user_id", :integer, :null => false
      t.column "data", :text, :null => false
      t.column "host", :text, :null => false
      t.column "ip", :text, :null => false
      t.column "comment", :text, :null => false
    end

    add_index "revisions", ["page_id"], :name => "revisions_page_id_index"
    add_index "revisions", ["user_id"], :name => "revisions_user_id_index"

    create_table "users", :force => true do |t|
      t.column "created_at", :datetime, :null => false
      t.column "updated_at", :datetime, :null => false
      t.column "login", :text, :null => false
      t.column "password", :text, :null => false
      t.column "email", :text, :null => false
      t.column "admin", :integer, :default => 0, :null => false
    end

    add_index "users", ["login"], :name => "users_user_index", :unique => true

  end

  def self.down
  end
end

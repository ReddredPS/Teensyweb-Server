require File.dirname(__FILE__) + '/../test_helper'

class RevisionTest < Test::Unit::TestCase
  fixtures :revisions

  # Replace this with your real tests.
  def test_truth
    assert_kind_of Revision, revisions(:first)
  end
end

require File.dirname(__FILE__) + '/../test_helper'

class TopicTest < Test::Unit::TestCase
  fixtures :topics

  # Replace this with your real tests.
  def test_truth
    assert_kind_of Topic, topics(:first)
  end
end
